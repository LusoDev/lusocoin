Sample configuration files for:

SystemD: lusod.service
Upstart: lusod.conf
OpenRC:  lusod.openrc
         lusod.openrcconf
CentOS:  lusod.init
OS X:    org.luso.lusod.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
